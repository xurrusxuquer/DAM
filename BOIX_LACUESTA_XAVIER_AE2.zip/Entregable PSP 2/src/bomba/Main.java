package bomba;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner scanner = new Scanner (System.in);
		
		ArrayList nums = new ArrayList();
		App prueba = new App();
		int num1;
		int num2;
		int numscan = 0;
		
		

		System.out.println("Elige el método que quieres ejecutar");
		System.out.println("1. sayHello");
		System.out.println("2. Intervalo de números");
		System.out.println("3. Nombres de compañeros de clase");
		
		switch(scanner.nextInt()) {
		case 1:
			App.sayHello();
			break;
		case 2:
			System.out.println("Introduce 2 números");
			num1 = scanner.nextInt();
			num2 = scanner.nextInt();
			intervalo(num1, num2);
		case 3:
			System.out.println("Introduce números hasta que introduzcas el 0");
			do {
				numscan = scanner.nextInt();
				if (numscan == 0) {
					nombreCompañeros(nums);
				}
				nums.add(numscan);
			} while (numscan != 0);
		}
		
		
	}
	
	public static void intervalo (int num1, int num2) {
		
		
		for (int i = num1; i <= num2; i++) {
			System.out.print(i + " ");
			num1 = num1 + i;
		}
		System.out.println("");
		System.out.println("Suma de todos los números: " + num1);
		
		return;
	}
	
	public static void nombreCompañeros (ArrayList nums) {
		
		ArrayList numers = nums;
		ArrayList compas = new ArrayList();
		int cont = 1;
		
		compas.add("Fran");
		compas.add("Fermin");
		compas.add("Pablo");
		compas.add("Daniela");
		compas.add("Pedro");
		compas.add("Gonzalo");
		
		System.out.println(numers);

	}

}
