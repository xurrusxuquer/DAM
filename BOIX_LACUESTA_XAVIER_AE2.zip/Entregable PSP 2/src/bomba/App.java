package bomba;

public class App {

	public static void sayHello() {
		System.out.println("Hola mundo");
		return;
	}
}
