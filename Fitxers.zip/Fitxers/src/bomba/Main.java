package bomba;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Scanner;
import java.util.Date;

public class Main {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		 int opcio;

	        do {
	            System.out.println(" MENÚ DE GESTIÓ DE FITXERS");
	            System.out.println("1. Mostrar informació d'un fitxer/directori");
	            System.out.println("2. Crear una carpeta");
	            System.out.println("3. Crear un fitxer");
	            System.out.println("4. Eliminar un fitxer o carpeta");
	            System.out.println("5. Renombrar un fitxer o carpeta");
	            System.out.println("0. Salir");
	            System.out.print("Selecciona una opció: ");
	            opcio = scanner.nextInt();
	            scanner.nextLine();

	            switch (opcio) {
	                case 1:
	                    System.out.print("Introdueix el camí del fitxer o directori: ");
	                    String direccion = scanner.nextLine();
	                    File fitxerInformacio = new File(direccion);
	                    System.out.println(getInformfacio(fitxerInformacio));
	                    break;
	                case 2:
	                    System.out.print("Introdueix el camí on vols crear la carpeta: ");
	                    String direccionCarpeta = scanner.nextLine();
	                    if (creaCarpeta(direccionCarpeta)) {
	                        System.out.println("Carpeta creada correctament.");
	                    } else {
	                        System.out.println("No s'ha pogut crear la carpeta.");
	                    }
	                    break;
	                case 3:
	                    System.out.print("Introdueix el camí i el nom del fitxer que vols crear: ");
	                    String direccionFichero = scanner.nextLine();
	                    if (crearFichero(direccionFichero)) {
	                        System.out.println("Fitxer creat correctament.");
	                    } else {
	                        System.out.println("No s'ha pogut crear el fitxer.");
	                    }
	                    break;
	                case 4:
	                    System.out.print("Introdueix el camí del fitxer o carpeta que vols eliminar: ");
	                    String camiEliminar = scanner.nextLine();
	                    File fitxerEliminar = new File(camiEliminar);
	                    if (elimina(fitxerEliminar)) {
	                        System.out.println("Fitxer o carpeta eliminat correctament.");
	                    } else {
	                        System.out.println("No s'ha pogut eliminar.");
	                    }
	                    break;
	                case 5:
	                    System.out.print("Introdueix el camí del fitxer o carpeta que vols renombrar: ");
	                    String camiRenombrar = scanner.nextLine();
	                    File fitxerRenombrar = new File(camiRenombrar);
	                    System.out.print("Introdueix el nou nom: ");
	                    String nouNom = scanner.nextLine();
	                    if (renomena(fitxerRenombrar, nouNom)) {
	                        System.out.println("Fitxer o carpeta renombrat correctament.");
	                    } else {
	                        System.out.println("No s'ha pogut renombrar.");
	                    }
	                    break;
	                case 0:
	                    System.out.println("Adiós!");
	                    break;
	                default:
	                    System.out.println("Opció no vàlida.");
	            }
	        } while (opcio != 0);
	        
	}


	
	public static String getInformfacio (File direccion) {
		
		StringBuilder sb = new StringBuilder();
		SimpleDateFormat sd = new SimpleDateFormat ("dd/MM/yyyy HH:mm:ss");
		
		if (direccion.exists()) {
			sb.append("Nom: ").append(direccion.getName()).append(" ");
			sb.append("Tipo: ").append(direccion.isDirectory() ? "Directori" : "Fitxer").append(" ");
			sb.append("Ubicació: ").append(direccion.getAbsolutePath()).append(" ");
			sb.append("Última modificació: ").append(sd.format(direccion.lastModified())).append(" ");
			sb.append("Està ocult?: ").append(direccion.isHidden() ? "Si" : "No").append(" ");
			
			if (direccion.isFile()) {
				sb.append("Grandaria: ").append(direccion.length()).append(" bytes").append(" ");
			} else if (direccion.isDirectory()) {
				sb.append("Número d'elements: ").append(direccion.list().length).append(" ");
				sb.append("Espai lliure: ").append(direccion.getFreeSpace()).append(" ");
				sb.append("Espai disponible: ").append(direccion.getUsableSpace()).append(" ");
				sb.append("Espai total: ").append(direccion.getTotalSpace()).append(" ");
			} 
			
			return sb.toString();
		} else {
			return "El fitxer o el direcctori introduit no existeix";
		}
	}	
	
	public static boolean creaCarpeta(String direccion) {
		File carpeta = new File(direccion);
		if (!carpeta.exists()) {
			return carpeta.mkdir();
		}
		return false;
	}
	
	public static boolean crearFichero (String direccion) {
		File fichero = new File(direccion);
		try {
			return fichero.createNewFile();
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
		
	}
	
	public static boolean elimina (File fichero) {
		if (fichero.exists()) {
			return fichero.delete();
		}
		return false;
	}
	
	public static boolean renomena (File fichero, String nombrenou) {
		File ficheroNuevo = new File (fichero.getParent() + fichero.separator + nombrenou);
		return fichero.renameTo(ficheroNuevo);
	}
	
}
