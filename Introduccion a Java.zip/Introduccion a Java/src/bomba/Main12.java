package bomba;

import java.util.Scanner;

public class Main12 {

	public static void main(String[] args) {
	
		Scanner scanner = new Scanner(System.in);
        int[] notas = new int[10];


        int suspensos = 0;
        int aprobados = 0;
        int notables = 0;
        int sobresalientes = 0;
        int matricula = 0;


        for (int i = 0; i < 10; i++) {
            System.out.print("Introduce la nota " + (i + 1) + " (entre 0 y 10): ");
            notas[i] = scanner.nextInt();


            if (notas[i] < 0 || notas[i] > 10) {
                System.out.println("Nota inválida. Debe estar entre 0 y 10.");
                i--; 
            }
        }


        for (int nota : notas) {
            if (nota >= 0 && nota < 5) {
                suspensos++;
            } else if (nota >= 5 && nota < 7) {
                aprobados++;
            } else if (nota >= 7 && nota < 9) {
                notables++;
            } else if (nota >= 9 && nota < 10) {
                sobresalientes++;
            } else if (nota == 10) {
                matricula++;
            }
        }


        System.out.println("Resultados:");
        System.out.println("Suspensos: " + suspensos);
        System.out.println("Aprobados: " + aprobados);
        System.out.println("Notables: " + notables);
        System.out.println("Sobresalientes: " + sobresalientes);
        System.out.println("Matrículas de honor: " + matricula);

        scanner.close();

	}

}
