package bomba;

import java.util.Scanner;

public class Main11 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner (System.in);

		int dni;
		int div;
		int resto;
		
		System.out.println("Introduce tu numero de DNI");
		dni = scanner.nextInt();
		
		div = dni / 23;
		
		resto = dni - (div * 23);
		
		System.out.println(div);
		System.out.println(resto);
		
		if (resto == 1) {
			System.out.println(dni + "T");
		} else if (resto == 1){
			System.out.println(dni + "R");
		} else if (resto == 2){
			System.out.println(dni + "W");
		} else if (resto == 3){
			System.out.println(dni + "A");
		} else if (resto == 4){
			System.out.println(dni + "G");
		} else if (resto == 5){
			System.out.println(dni + "M");
		} else if (resto == 6){
			System.out.println(dni + "Y");
		} else if (resto == 7){
			System.out.println(dni + "F");
		} else if (resto == 8){
			System.out.println(dni + "P");
		} else if (resto == 9){
			System.out.println(dni + "D");
		} else if (resto == 10){
			System.out.println(dni + "X");
		} else if (resto == 11){
			System.out.println(dni + "B");
		} else if (resto == 12){
			System.out.println(dni + "N");
		} else if (resto == 13){
			System.out.println(dni + "J");
		} else if (resto == 14){
			System.out.println(dni + "Z");
		} else if (resto == 15){
			System.out.println(dni + "S");
		} else if (resto == 16){
			System.out.println(dni + "Q");
		} else if (resto == 17){
			System.out.println(dni + "V");
		} else if (resto == 18){
			System.out.println(dni + "H");
		} else if (resto == 19){
			System.out.println(dni + "L");
		} else if (resto == 20){
			System.out.println(dni + "C");
		} else if (resto == 21){
			System.out.println(dni + "K");
		} else if (resto == 22	){
			System.out.println(dni + "E");
		}		

	}

}
