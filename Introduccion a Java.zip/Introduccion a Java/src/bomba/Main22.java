package bomba;

import java.util.ArrayList;
import java.util.Scanner;

public class Main22 {

	 public static void main(String[] args) {
		 Scanner scanner = new Scanner(System.in);
	        
	        ArrayList<String> nombres = new ArrayList<>();
	        String nombre;

	        while (true) {
	            System.out.print("Introduce el nombre de una persona (pulsa '0' para terminar): ");
	            nombre = scanner.nextLine();

	            if (nombre.equals("0")) {
	                break;
	            }

	            nombres.add(nombre);
	        }

	        System.out.println("Los nombres almacenados son: ");
	        for (String n : nombres) {
	            System.out.println(n);
	        }

	    }

}
