package bomba;

import java.util.Scanner;

public class Main14 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

		double radio;
		double diametro;
		double area;
		
        System.out.print("Introduce el valor del radio: ");
        radio = scanner.nextDouble();

        diametro = 2 * radio;

        area = Math.PI * Math.pow(radio, 2);

        System.out.printf("El diámetro de la circunferencia es: ", diametro);
        System.out.printf("El área de la circunferencia es: ", area);
	}

}
