package bomba;

import java.util.Scanner;

public class Main6 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner (System.in);

		int cont = 0;
		int suma = 0;
		int num;

		do {
			
			System.out.println("Introduce un numero");
			num = scanner.nextInt();
			
			suma = num + suma;
			
			cont++;
			
		} while (cont != 5);
		
		System.out.println(suma);
	}

}
