package bomba;

import java.util.Scanner;

public class Main18 {

	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String contrasena;
        String comprobar;
        
        System.out.print("Introduce una contraseña: ");
        contrasena = scanner.nextLine();
        System.out.print("Vuelva a introducir la contraseña: ");
        comprobar = scanner.nextLine();
        
        if (contrasena == comprobar) {

        	if (esContrasenaValida(contrasena)) {
            System.out.println("La contraseña es válida.");
        	} else {
            System.out.println("La contraseña no cumple con los requisitos.");
        	}
        } else {
        	System.out.println("Las contraseñas no coinciden");
        }

    }

    public static boolean esContrasenaValida(String contrasena) {

        if (contrasena.length() < 5) {
            return false;
        }

        boolean contieneNumero = false;
        boolean contieneMayuscula = false;

        for (int i = 0; i < contrasena.length(); i++) {
            char caracter = contrasena.charAt(i);

            if (Character.isDigit(caracter)) {
                contieneNumero = true;
            }

            if (Character.isUpperCase(caracter)) {
                contieneMayuscula = true;
            }
        }

        return contieneNumero && contieneMayuscula;
    }

}
