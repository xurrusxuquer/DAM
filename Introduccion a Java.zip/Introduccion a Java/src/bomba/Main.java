package bomba;

public class Main {
	public static void main (String args[]) {
		
		int num1 = 8;
		int num2 = 10;
		int suma = num1 + num2;
		
		System.out.println(suma);
	}
}
