package bomba;

import java.util.Scanner;

public class Main3 {
	public static void main(String args[]) {

		Scanner scanner = new Scanner (System.in);
		
	int num1 = 0;
	int num2 = 0; 
	int suma = num1 + num2;
	
	System.out.println("Introduce un numero");
	num1 = scanner.nextInt();
	
	System.out.println("Introduce otro número");
	num2 = scanner.nextInt();
	
	System.out.println(suma);
	
	}
}
