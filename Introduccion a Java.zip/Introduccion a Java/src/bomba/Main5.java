package bomba;

import java.util.Scanner;

public class Main5 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner (System.in);

		int num1;
		int num2;
		
		do {
			
			System.out.println("Introduce el primer número");
			num1 = scanner.nextInt();
			System.out.println("Introduce el segundo número");
			num2 = scanner.nextInt();
			
		} while (num1 != num2);

	}

}
