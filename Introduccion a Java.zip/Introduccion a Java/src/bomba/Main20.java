package bomba;

public class Main20 {

	public static void main(String[] args) {

        System.out.println("Código ASCII | Carácter");
        System.out.println("------------------------");

        // Recorrer todos los códigos ASCII desde 0 hasta 127
        for (int i = 0; i <= 255; i++) {
            // Mostrar el código y el carácter correspondiente
            System.out.printf("%11d | %c%n", i, (char) i);
        }
    }
}
