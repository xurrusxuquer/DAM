package bomba;

import java.util.Scanner;

public class Main16 {

	public static void main(String[] args) {
		
        Scanner scanner = new Scanner(System.in);

        int suma;
        int dia;
        int mes;
        int ano;
        
        System.out.print("Introduce el dia que naciste ");
        dia = scanner.nextInt();
        System.out.println("Introduce el mes que naciste");
        mes = scanner.nextInt();
        System.out.println("Introduce el año que naciste");
        ano = scanner.nextInt();
        
        suma = (ano + dia) / mes;


        System.out.println("Tu número de la suerte es: " + suma);

	}

}
