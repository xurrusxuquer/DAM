package bomba;

import java.util.Scanner;

public class Main4 {

	public static void main(String[] args) {

		Scanner scanner = new Scanner (System.in);
		
	int num1 = 0;
	int num2 = 0; 
	int suma = num1 + num2;
	
	System.out.println("Introduce un numero");
	num1 = scanner.nextInt();
	
	System.out.println("Introduce otro número");
	num2 = scanner.nextInt();
	

	if (num1 == num2) {
		System.out.println("Los números son iguales");
	} else if (num1 > num2) {
		System.out.println("El primer número introducido es mayor que el segundo");
	} else {
		System.out.println("El segundo número introducido es mayor que el primero");
	}
	
	
	}

}
