package bomba;

import java.util.Scanner;

public class Main17 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Introduce una contraseña: ");
        String contrasena = scanner.nextLine();

        if (esContrasenaValida(contrasena)) {
            System.out.println("La contraseña es válida.");
        } else {
            System.out.println("La contraseña no cumple con los requisitos.");
        }


    }

    public static boolean esContrasenaValida(String contrasena) {

        if (contrasena.length() < 5) {
            return false;
        }

        boolean contieneNumero = false;
        boolean contieneMayuscula = false;

        for (int i = 0; i < contrasena.length(); i++) {
            char caracter = contrasena.charAt(i);

            if (Character.isDigit(caracter)) {
                contieneNumero = true;
            }

            if (Character.isUpperCase(caracter)) {
                contieneMayuscula = true;
            }
        }

        return contieneNumero && contieneMayuscula;
    }

}
