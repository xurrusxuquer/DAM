package bomba;

import java.util.Scanner;

public class Main15 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

		double radio;
		double diametro;
		double area;
		double volumen;
		
        System.out.print("Introduce el valor del radio: ");
        radio = scanner.nextDouble();

        diametro = 2 * radio;

        area = Math.PI * Math.pow(radio, 2);
        
        volumen = (4.0 / 3.0) * Math.PI * Math.pow(radio, 3);

        System.out.println("El diámetro de la circunferencia es: " + diametro);
        System.out.println("El área de la circunferencia es: " + area);
        System.out.println("El volumen de la circunferencia es: " + volumen);
	}

}
