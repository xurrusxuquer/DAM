package bomba;

import java.util.Scanner;

public class Main21 {

	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        String[] nombres = new String[5];

        for (int i = 0; i < nombres.length; i++) {
            System.out.print("Introduce el nombre de la persona " + (i + 1) + ": ");
            nombres[i] = scanner.nextLine();
        }

        System.out.println("Los nombres almacenados son: ");
        for (String nombre : nombres) {
            System.out.println(nombre);
        }
	}

}
