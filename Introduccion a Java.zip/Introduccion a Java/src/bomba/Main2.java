package bomba;

import java.util.Scanner;

public class Main2 {

	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);
		String teclado;
		
		System.out.println("Introduce algo");
		teclado = scanner.nextLine();
		
		System.out.println("Hola" + " " + teclado);
	}

}
