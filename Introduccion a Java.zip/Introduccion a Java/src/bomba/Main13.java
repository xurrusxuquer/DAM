package bomba;

import java.util.Scanner;

public class Main13 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

		double tempc;
		double tempf;
		
		System.out.println("Introduce la temperatura en grados celcius");
		tempc = scanner.nextDouble();
		
		tempf = (tempc * 9 / 5) + 32;
		
		System.out.println("La temperatura en Fahrenheit es: " + tempf);
	}

}
