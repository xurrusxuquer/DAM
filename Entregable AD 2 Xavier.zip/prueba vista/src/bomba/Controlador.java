package bomba;

import java.awt.event.*;
import java.io.*;
import javax.swing.JOptionPane;

public class Controlador {
    private Model modelo;
    private Vista vista;
    private String rutaArchivoOriginal = "texto.txt";
    private String rutaArchivoModificado = "modificado.txt"; // Ruta para guardar el archivo modificado

    public Controlador(Model modelo, Vista vista) {
        this.modelo = modelo;
        this.vista = vista;

        try {
            String texto = modelo.cargarArchivo(rutaArchivoOriginal);
            vista.getTextAreaOriginal().setText(texto);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(vista.getTextAreaOriginal(), "Error al cargar el archivo");
        }

        vista.getBtnBuscar().addActionListener(new ActionListener() {
        	@Override
            public void actionPerformed(ActionEvent e) {
                String palabraBuscar = vista.getTextFieldBuscar().getText();
                int contador = modelo.buscarPalabra(palabraBuscar);
                JOptionPane.showMessageDialog(vista.getTextAreaOriginal(),
                        "La palabra \"" + palabraBuscar + "\" aparece " + contador + " veces.");
            }
        });

        vista.getBtnReemplazar().addActionListener(new ActionListener() {
        	@Override
            public void actionPerformed(ActionEvent e) {
                String palabraBuscar = vista.getTextFieldBuscar().getText();
                String palabraReemplazar = vista.getTextFieldReemplazar().getText();
                String textoModificado = modelo.reemplazarPalabra(palabraBuscar, palabraReemplazar);
                vista.getTextAreaModificado().setText(textoModificado);

                try {
                    modelo.guardarArchivo(rutaArchivoModificado);
                } catch (IOException ex) {
                    JOptionPane.showMessageDialog(vista.getTextAreaModificado(), "Error al guardar el archivo modificado");
                }
            }
        });
    }
}

