package bomba;

public class Principal {

	public static void main(String[] args) {

		Model modelo = new Model();
	    Vista vista = new Vista();
	    Controlador controlador = new Controlador(modelo, vista);
	}

}
