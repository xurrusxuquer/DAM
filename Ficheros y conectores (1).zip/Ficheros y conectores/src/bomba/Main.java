package bomba;

import java.io.File;
import java.util.Scanner;

public class Main {
	public static void ejer1 (String args []) {
		
		Scanner scanner = new Scanner(System.in);
		String directorios;
		
		System.out.println("Introduce un directorio");
		directorios = scanner.nextLine();
		
		File directorio = new File(directorios);
		System.out.println(directorio.getPath());
	}
	

}
