package bomba;

import java.io.File;
import java.io.FileFilter;

public class Filtro implements FileFilter{

	private String extension;
	
	public Filtro (String extension) {
		super();
		this.extension = extension;
	}
	
	@Override
	public boolean accept(File archivo) {
		if(archivo.getName().endsWith(extension)) {
			return true;
		}
		return false;
		
	}
}
