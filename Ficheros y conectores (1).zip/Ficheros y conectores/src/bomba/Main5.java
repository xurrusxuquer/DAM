package bomba;

import java.io.File;
import java.util.Scanner;

public class Main5 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		String directorio;
		String extension;
		
		System.out.println("Dime el directorio que quieres comprobar");
		directorio = scanner.nextLine();
		System.out.println("Dime la extension que quieres comprobar");
		extension = scanner.nextLine();
		
		File archivo = new File(directorio);
		Filtro filtro = new Filtro(extension);
		
		File[] ficherosFiltro = archivo.listFiles();
		
		for (File filtro2 : ficherosFiltro) {
			if(filtro.accept(filtro2)) {
				System.out.println(filtro2.getName());
			}
		}
		
	}

}
