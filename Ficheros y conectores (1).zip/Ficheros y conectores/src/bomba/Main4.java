package bomba;

import java.io.File;
import java.util.Scanner;

public class Main4 {

	public static void main(String[] args) {

Scanner scanner = new Scanner(System.in);
		
		String directorio;
		
		System.out.println("Introduce el directorio");
		directorio = scanner.nextLine();

		
		File direc = new File(directorio);
		
		if (direc.exists() == true) {
			System.out.println("¡El directorio existe!");
		} else if (direc.exists() == false) {
			System.out.println("ERROR: El directorio NO existe");
		}
	}

}
