package bomba;

import java.io.File;
import java.util.Scanner;

public class Main2 {

	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);
		
		String directorio;
		String nombre;
		
		System.out.println("Introduce el directorio");
		directorio = scanner.nextLine();
		System.out.println("Introduce el nombre sin la ruta");
		nombre = scanner.nextLine();
		
		File direc = new File(directorio);
		
		System.out.println("¿Se puede leer?");
		System.out.println(nombre + " " + direc.canRead());
		System.out.println("¿Se puede editar?");
		System.out.println(nombre + " " + direc.canWrite());
		System.out.println("¿Se puede ejecutar?");
		System.out.println(nombre + " " + direc.canExecute());
		
	}

}
