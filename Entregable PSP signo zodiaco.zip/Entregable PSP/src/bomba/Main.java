package bomba;

import java.util.Random;
import java.util.Scanner;

public class Main {
	public static void main (String args[]) {
		  Scanner scanner = new Scanner(System.in);

	        System.out.print("Introduce tu dia de nacimiento (1-31): ");
	        int dia = scanner.nextInt();
	        System.out.print("Introduce tu mes de nacimiento (1-12): ");
	        int mes = scanner.nextInt();
	        
	        getSigno(dia, mes);
	        getPrediccion();
	        
	}
	
	public static void getSigno (int dia, int mes) {
		
		String signo;

	        if (mes == 1) {
	            signo = (dia <= 19) ? "Capricornio" : "Acuario";
	        } else if (mes == 2) {
	        	signo = (dia <= 18) ? "Acuario" : "Piscis";
	        } else if (mes == 3) {
	        	signo = (dia <= 20) ? "Piscis" : "Áries";
	        } else if (mes == 4) {
	        	signo = (dia <= 19) ? "Áries" : "Tauro";
	        } else if (mes == 5) {
	        	signo = (dia <= 20) ? "Tauro" : "Géminis";
	        } else if (mes == 6) {
	        	signo = (dia <= 20) ? "Géminis" : "Cáncer";
	        } else if (mes == 7) {
	        	signo = (dia <= 22) ? "Cáncer" : "Leo";
	        } else if (mes == 8) {
	        	signo = (dia <= 22) ? "Leo" : "Virgo";
	        } else if (mes == 9) {
	        	signo = (dia <= 22) ? "Virgo" : "Libra";
	        } else if (mes == 10) {
	        	signo = (dia <= 22) ? "Libra" : "Escorpio";
	        } else if (mes == 11) {
	        	signo = (dia <= 21) ? "Escorpio" : "Sagitario";
	        } else if (mes == 12) {
	        	signo = (dia <= 21) ? "Sagitario" : "Capricornio";
	        } else {
	            System.out.println("Data no vàlida");
	            return;
	        }

	        System.out.println("Tu signo del zodíaco es: " + signo);
	        
	}
	
	public static void getPrediccion() {
		
        String[] predicciones = {
	            "Mañana vas a tener un mal dia",
	            "Mañana vas a tener un buen dia",
	            "Hoy pasará algo relacionado con tu salud",
	            "Las oportunidades más importantes salen cuando no te las esperas",
	            "Un sueño de hace mucho tiempo se cumplirá hoy",
	            "Hoy todas tus relaciones amistosas van a aumentar",
	            "Hoy vas a ser muy creativo"
	        };
		
        Random random = new Random();

        String prediccioAleatoria = predicciones[random.nextInt(predicciones.length)];

        System.out.println("Tu predicción de hoy: " + prediccioAleatoria);
	}

	}
